<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* lesGenres.html.twig */
class __TwigTemplate_d511f22dadbca86a3247778424ff13c49c2febb9befaddaa8859a22702708309 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'central' => [$this, 'block_central'],
            'flash_messages' => [$this, 'block_flash_messages'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "lesGenres.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "lesGenres.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "lesGenres.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_central($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "central"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "central"));

        // line 4
        echo "<!-- page start-->
<div class=\"col-sm-8\">
\t<section class=\"panel\">
\t\t<div class=\"chat-room-head\">
\t\t\t<h3><i class=\"fa fa-angle-right\"></i> Gérer les genres</h3>
\t\t</div>
\t\t<div class=\"panel-body\">
\t\t\t<table class=\"table table-striped table-advance table-hover\">
\t\t\t<thead>
\t\t\t  <tr class=\"tableau-entete\">
\t\t\t\t<th><i class=\"fa fa-bullhorn\"></i> Identifiant</th>
\t\t\t\t<th><i class=\"fa fa-bookmark\"></i> Libellé</th>
\t\t\t\t<th><i class=\"fa fa-bookmark\"></i> Spécialiste</th>
\t\t\t\t<th><i class=\"fa fa-bookmark\"></i> Nombre jeux</th>
\t\t\t\t<th></th>
\t\t\t  </tr>
\t\t\t</thead>
\t\t\t<tbody>

\t\t\t";
        // line 23
        $this->displayBlock('flash_messages', $context, $blocks);
        // line 33
        echo "
\t\t\t<!-- formulaire pour ajouter un nouveau genre-->
\t\t\t<tr>
\t\t\t<form action=\"";
        // line 36
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("genres_ajouter");
        echo "\" method=\"post\">
\t\t\t\t<td>Nouveau</td>
\t\t\t\t<td>
\t\t\t\t\t<input type=\"text\" id=\"txtLibGenre\" name=\"txtLibGenre\" size=\"24\" required minlength=\"4\"  maxlength=\"24\"  placeholder=\"Libellé\" title=\"De 4 à 24 caractères\"  />
\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t\t";
        // line 42
        list($context["tbObjets"], $context["name"], $context["size"], $context["idSelect"]) =         [(isset($context["tbMembres"]) || array_key_exists("tbMembres", $context) ? $context["tbMembres"] : (function () { throw new RuntimeError('Variable "tbMembres" does not exist.', 42, $this->source); })()), "lstMembre", 1, ""];
        // line 43
        echo "\t\t\t\t\t";
        echo twig_include($this->env, $context, "liste.html.twig");
        echo "
\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t\t0
\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t\t<button class=\"btn btn-primary btn-xs\" type=\"submit\" name=\"cmdAction\" value=\"ajouterNouveauGenre\" title=\"Enregistrer nouveau genre\"><i class=\"fa fa-save\"></i></button>
\t\t\t\t\t<button class=\"btn btn-info btn-xs\" type=\"reset\" title=\"Effacer la saisie\"><i class=\"fa fa-eraser\"></i></button>
\t\t\t\t</td>
\t\t\t</form>
\t\t\t</tr>

\t\t\t";
        // line 55
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tbGenres"]) || array_key_exists("tbGenres", $context) ? $context["tbGenres"] : (function () { throw new RuntimeError('Variable "tbGenres" does not exist.', 55, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["genre"]) {
            // line 56
            echo "\t\t\t  <tr>

\t\t\t\t<!-- formulaire pour demander la modification et supprimer les genres-->
\t\t\t\t<form method=\"post\">
                    <td>";
            // line 60
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["genre"], "identifiant", [], "any", false, false, false, 60), "html", null, true);
            echo "<input type=\"hidden\"  name=\"txtIdGenre\" value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["genre"], "identifiant", [], "any", false, false, false, 60), "html", null, true);
            echo "\" /></td>
                    <td>
\t\t\t\t\t";
            // line 62
            if ((twig_get_attribute($this->env, $this->source, $context["genre"], "identifiant", [], "any", false, false, false, 62) != (isset($context["idGenreModif"]) || array_key_exists("idGenreModif", $context) ? $context["idGenreModif"] : (function () { throw new RuntimeError('Variable "idGenreModif" does not exist.', 62, $this->source); })()))) {
                // line 63
                echo "\t\t\t\t\t  ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["genre"], "libelle", [], "any", false, false, false, 63), "html", null, true);
                echo "
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t";
                // line 66
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["genre"], "nomSpecialiste", [], "any", false, false, false, 66), "html", null, true);
                echo "
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t";
                // line 69
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["genre"], "nbJeux", [], "any", false, false, false, 69), "html", null, true);
                echo "
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t";
                // line 72
                if ((((isset($context["notification"]) || array_key_exists("notification", $context) ? $context["notification"] : (function () { throw new RuntimeError('Variable "notification" does not exist.', 72, $this->source); })()) != "rien") && (twig_get_attribute($this->env, $this->source, $context["genre"], "identifiant", [], "any", false, false, false, 72) == (isset($context["idGenreNotif"]) || array_key_exists("idGenreNotif", $context) ? $context["idGenreNotif"] : (function () { throw new RuntimeError('Variable "idGenreNotif" does not exist.', 72, $this->source); })())))) {
                    // line 73
                    echo "\t\t\t\t\t\t\t\t<button class=\"btn btn-success btn-xs\"><i class=\"fa fa-check\"></i> ";
                    echo twig_escape_filter($this->env, (isset($context["notification"]) || array_key_exists("notification", $context) ? $context["notification"] : (function () { throw new RuntimeError('Variable "notification" does not exist.', 73, $this->source); })()), "html", null, true);
                    echo "</button>
\t\t\t\t\t\t\t";
                }
                // line 75
                echo "\t\t\t\t\t\t\t<button class=\"btn btn-primary btn-xs\" type=\"submit\" name=\"cmdAction\" value=\"demanderModifierGenre\" title=\"Modifier\" formaction=\"";
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("genres_demandermodifier");
                echo "\"><i class=\"fa fa-pencil\"></i></button>
\t\t\t\t\t\t\t<button class=\"btn btn-danger btn-xs\" type=\"submit\" name=\"cmdAction\" value=\"supprimerGenre\" title=\"Supprimer\" formaction=\"";
                // line 76
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("genres_supprimer");
                echo "\" onclick=\"return confirm('Voulez-vous vraiment supprimer ce genre ?');\"><i class=\"fa fa-trash-o \"></i></button>
\t\t\t\t\t\t</td>
";
                // line 79
                echo "\t\t\t\t\t";
            } else {
                // line 80
                echo "\t\t\t\t\t\t<input type=\"text\" id=\"txtLibGenre\" name=\"txtLibGenre\" size=\"24\" required minlength=\"4\"  maxlength=\"24\"   value=\"";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["genre"], "libelle", [], "any", false, false, false, 80), "html", null, true);
                echo "\" />
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t<!--<?php afficherListe(\$tbMembres, 'lstMembre', 1, \$genre->idSpecialiste); ?>-->
\t\t\t\t\t\t\t";
                // line 84
                list($context["tbObjets"], $context["name"], $context["size"], $context["idSelect"]) =                 [(isset($context["tbMembres"]) || array_key_exists("tbMembres", $context) ? $context["tbMembres"] : (function () { throw new RuntimeError('Variable "tbMembres" does not exist.', 84, $this->source); })()), "lstMembre", 1, twig_get_attribute($this->env, $this->source, $context["genre"], "idSpecialiste", [], "any", false, false, false, 84)];
                // line 85
                echo "\t\t\t\t\t\t\t";
                echo twig_include($this->env, $context, "liste.html.twig");
                echo "
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t";
                // line 88
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["genre"], "nbJeux", [], "any", false, false, false, 88), "html", null, true);
                echo "
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t<button class=\"btn btn-primary btn-xs\" type=\"submit\" name=\"cmdAction\" value=\"validerModifierGenre\" title=\"Enregistrer\" formaction=\"";
                // line 91
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("genres_validerModifier");
                echo "\"><i class=\"fa fa-save\"></i></button>
\t\t\t\t\t\t\t<button class=\"btn btn-info btn-xs\" type=\"reset\" title=\"Effacer la saisie\"><i class=\"fa fa-eraser\"></i></button>
\t\t\t\t\t\t\t<button class=\"btn btn-warning btn-xs\" type=\"submit\" name=\"cmdAction\" value=\"annulerModifierGenre\" title=\"Annuler\" formaction=\"";
                // line 93
                echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("genres_afficher");
                echo "\"><i class=\"fa fa-undo\"></i></button>
\t\t\t\t\t\t</td>
\t\t\t\t\t";
            }
            // line 96
            echo "
\t\t\t\t</form>

\t\t\t  </tr>
\t\t\t";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['genre'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 101
        echo "\t\t\t</tbody>
\t\t  </table>
\t\t\t  \t  
\t\t</div><!-- fin div panel-body-->
    </section><!-- fin section genres-->
</div><!--fin div col-sm-8-->

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 23
    public function block_flash_messages($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "flash_messages"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "flash_messages"));

        // line 24
        echo "\t\t\t\t";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 24, $this->source); })()), "session", [], "any", false, false, false, 24), "flashbag", [], "any", false, false, false, 24), "all", [], "method", false, false, false, 24));
        foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
            // line 25
            echo "\t\t\t\t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["messages"]);
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 26
                echo "\t\t\t\t\t\t<div class=\"alert alert-";
                echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                echo " alert-dismissible\" role=\"alert\">
\t\t\t\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>
\t\t\t\t\t\t\t";
                // line 28
                echo $context["message"];
                echo "
\t\t\t\t\t\t</div>
\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 31
            echo "\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "\t\t\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "lesGenres.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  306 => 32,  300 => 31,  291 => 28,  285 => 26,  280 => 25,  275 => 24,  265 => 23,  248 => 101,  230 => 96,  224 => 93,  219 => 91,  213 => 88,  206 => 85,  204 => 84,  196 => 80,  193 => 79,  188 => 76,  183 => 75,  177 => 73,  175 => 72,  169 => 69,  163 => 66,  156 => 63,  154 => 62,  147 => 60,  141 => 56,  124 => 55,  108 => 43,  106 => 42,  97 => 36,  92 => 33,  90 => 23,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("﻿{% extends \"base.html.twig\" %}

{% block central %}
<!-- page start-->
<div class=\"col-sm-8\">
\t<section class=\"panel\">
\t\t<div class=\"chat-room-head\">
\t\t\t<h3><i class=\"fa fa-angle-right\"></i> Gérer les genres</h3>
\t\t</div>
\t\t<div class=\"panel-body\">
\t\t\t<table class=\"table table-striped table-advance table-hover\">
\t\t\t<thead>
\t\t\t  <tr class=\"tableau-entete\">
\t\t\t\t<th><i class=\"fa fa-bullhorn\"></i> Identifiant</th>
\t\t\t\t<th><i class=\"fa fa-bookmark\"></i> Libellé</th>
\t\t\t\t<th><i class=\"fa fa-bookmark\"></i> Spécialiste</th>
\t\t\t\t<th><i class=\"fa fa-bookmark\"></i> Nombre jeux</th>
\t\t\t\t<th></th>
\t\t\t  </tr>
\t\t\t</thead>
\t\t\t<tbody>

\t\t\t{% block flash_messages %}
\t\t\t\t{% for type, messages in app.session.flashbag.all() %}
\t\t\t\t\t{% for message in messages %}
\t\t\t\t\t\t<div class=\"alert alert-{{ type }} alert-dismissible\" role=\"alert\">
\t\t\t\t\t\t\t<button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>
\t\t\t\t\t\t\t{{ message | raw }}
\t\t\t\t\t\t</div>
\t\t\t\t\t{% endfor %}
\t\t\t\t{% endfor %}
\t\t\t{% endblock %}

\t\t\t<!-- formulaire pour ajouter un nouveau genre-->
\t\t\t<tr>
\t\t\t<form action=\"{{path('genres_ajouter')}}\" method=\"post\">
\t\t\t\t<td>Nouveau</td>
\t\t\t\t<td>
\t\t\t\t\t<input type=\"text\" id=\"txtLibGenre\" name=\"txtLibGenre\" size=\"24\" required minlength=\"4\"  maxlength=\"24\"  placeholder=\"Libellé\" title=\"De 4 à 24 caractères\"  />
\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t\t{% set tbObjets, name, size, idSelect = tbMembres, 'lstMembre', 1, '' %}
\t\t\t\t\t{{ include('liste.html.twig') }}
\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t\t0
\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t\t<button class=\"btn btn-primary btn-xs\" type=\"submit\" name=\"cmdAction\" value=\"ajouterNouveauGenre\" title=\"Enregistrer nouveau genre\"><i class=\"fa fa-save\"></i></button>
\t\t\t\t\t<button class=\"btn btn-info btn-xs\" type=\"reset\" title=\"Effacer la saisie\"><i class=\"fa fa-eraser\"></i></button>
\t\t\t\t</td>
\t\t\t</form>
\t\t\t</tr>

\t\t\t{% for key, genre in tbGenres %}
\t\t\t  <tr>

\t\t\t\t<!-- formulaire pour demander la modification et supprimer les genres-->
\t\t\t\t<form method=\"post\">
                    <td>{{ genre.identifiant }}<input type=\"hidden\"  name=\"txtIdGenre\" value=\"{{ genre.identifiant }}\" /></td>
                    <td>
\t\t\t\t\t{% if genre.identifiant != idGenreModif %}
\t\t\t\t\t  {{ genre.libelle }}
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t{{ genre.nomSpecialiste }}
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t{{genre.nbJeux}}
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t{% if notification != 'rien' and genre.identifiant == idGenreNotif %}
\t\t\t\t\t\t\t\t<button class=\"btn btn-success btn-xs\"><i class=\"fa fa-check\"></i> {{ notification }}</button>
\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t<button class=\"btn btn-primary btn-xs\" type=\"submit\" name=\"cmdAction\" value=\"demanderModifierGenre\" title=\"Modifier\" formaction=\"{{path('genres_demandermodifier')}}\"><i class=\"fa fa-pencil\"></i></button>
\t\t\t\t\t\t\t<button class=\"btn btn-danger btn-xs\" type=\"submit\" name=\"cmdAction\" value=\"supprimerGenre\" title=\"Supprimer\" formaction=\"{{path('genres_supprimer')}}\" onclick=\"return confirm('Voulez-vous vraiment supprimer ce genre ?');\"><i class=\"fa fa-trash-o \"></i></button>
\t\t\t\t\t\t</td>
{#\t\t\t\t\tdocument.getElementById('form1').submit();#    document.getElementBYId('form1').action=\"{{ path('genres_supprimer') }}  #}
\t\t\t\t\t{% else %}
\t\t\t\t\t\t<input type=\"text\" id=\"txtLibGenre\" name=\"txtLibGenre\" size=\"24\" required minlength=\"4\"  maxlength=\"24\"   value=\"{{ genre.libelle }}\" />
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t<!--<?php afficherListe(\$tbMembres, 'lstMembre', 1, \$genre->idSpecialiste); ?>-->
\t\t\t\t\t\t\t{% set tbObjets, name, size, idSelect = tbMembres, 'lstMembre', 1, genre.idSpecialiste %}
\t\t\t\t\t\t\t{{ include('liste.html.twig') }}
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t{{ genre.nbJeux }}
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t<button class=\"btn btn-primary btn-xs\" type=\"submit\" name=\"cmdAction\" value=\"validerModifierGenre\" title=\"Enregistrer\" formaction=\"{{path('genres_validerModifier')}}\"><i class=\"fa fa-save\"></i></button>
\t\t\t\t\t\t\t<button class=\"btn btn-info btn-xs\" type=\"reset\" title=\"Effacer la saisie\"><i class=\"fa fa-eraser\"></i></button>
\t\t\t\t\t\t\t<button class=\"btn btn-warning btn-xs\" type=\"submit\" name=\"cmdAction\" value=\"annulerModifierGenre\" title=\"Annuler\" formaction=\"{{path('genres_afficher')}}\"><i class=\"fa fa-undo\"></i></button>
\t\t\t\t\t\t</td>
\t\t\t\t\t{% endif %}

\t\t\t\t</form>

\t\t\t  </tr>
\t\t\t{% endfor %}
\t\t\t</tbody>
\t\t  </table>
\t\t\t  \t  
\t\t</div><!-- fin div panel-body-->
    </section><!-- fin section genres-->
</div><!--fin div col-sm-8-->

{% endblock %}

", "lesGenres.html.twig", "C:\\wamp64\\www\\AgoraBoS\\templates\\lesGenres.html.twig");
    }
}
