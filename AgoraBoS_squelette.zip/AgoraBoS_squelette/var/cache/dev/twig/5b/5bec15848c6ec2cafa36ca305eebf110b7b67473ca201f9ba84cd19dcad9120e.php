<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* menu.html.twig */
class __TwigTemplate_1f769030b3b7b01c12f0d36d4f3c8182b5de3f4db50343b1e77830c6b11cc6d1 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "menu.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "menu.html.twig"));

        // line 1
        echo "    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id=\"sidebar\" class=\"nav-collapse \">
        <!-- sidebar menu start-->
        <ul class=\"sidebar-menu\" id=\"nav-accordion\">
          <p class=\"centered\"><a href=\"profile.html\"><img src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/greece-1162816_640.jpg"), "html", null, true);
        echo "\" class=\"img-circle\" width=\"80\"></a></p>
          <h5 class=\"centered\">MJC Agora</h5>

          <li class=\"sub-menu\">
            <a
              ";
        // line 14
        if (((isset($context["menuActif"]) || array_key_exists("menuActif", $context)) && ((isset($context["menuActif"]) || array_key_exists("menuActif", $context) ? $context["menuActif"] : (function () { throw new RuntimeError('Variable "menuActif" does not exist.', 14, $this->source); })()) == "Jeux"))) {
            echo " class=\"active\"  ";
        }
        // line 15
        echo "              href=\"index.php\" ><i class=\"fa fa-desktop\"></i>
              <span>Jeux vidéos</span>
              </a>
            <ul class=\"sub\">
              <li><a href=\"index.php?uc=gererJeux&action=afficherJeux\">Jeux</a></li>
              <li><a href=\"";
        // line 20
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("genres_afficher");
        echo "\">Genres</a></li>
              <li><a href=\"index.php?uc=gererPlateformes&action=afficherPlateformes\">Plateformes</a></li>
              <li><a href=\"index.php?uc=gererMarques&action=afficherMarques\">Marques</a></li>
              <li><a href=\"index.php?uc=gererPegis&action=afficherPegis\">Pegi</a></li>
\t\t\t  <li><a href=\"index.php?uc=gererTournois&action=afficherTournois\">Tournois</a></li>
            </ul>
          </li>
\t\t  <li class=\"sub-menu\">
            <a
              ";
        // line 29
        if (((isset($context["menuActif"]) || array_key_exists("menuActif", $context)) && ((isset($context["menuActif"]) || array_key_exists("menuActif", $context) ? $context["menuActif"] : (function () { throw new RuntimeError('Variable "menuActif" does not exist.', 29, $this->source); })()) == "Clubs"))) {
            echo " class=\"active\"  ";
        }
        // line 30
        echo "              href=\"javascript:;\">
              <i class=\"fa fa-group\"></i>
              <span>Clubs d'activités</span>
              </a>
            <ul class=\"sub\">
              <li><a href=\"";
        // line 35
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 1</a></li>
              <li><a href=\"";
        // line 36
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 2</a></li>
              <li><a href=\"";
        // line 37
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 3</a></li>
              <li><a href=\"";
        // line 38
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 4</a></li>
\t\t\t  <li><a href=\"";
        // line 39
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 5</a></li>
            </ul>
          </li>
\t\t  
          <li class=\"sub-menu\">
            <a
              ";
        // line 45
        if (((isset($context["menuActif"]) || array_key_exists("menuActif", $context)) && ((isset($context["menuActif"]) || array_key_exists("menuActif", $context) ? $context["menuActif"] : (function () { throw new RuntimeError('Variable "menuActif" does not exist.', 45, $this->source); })()) == "Formations"))) {
            echo " class=\"active\"  ";
        }
        // line 46
        echo "              href=\"javascript:;\">
              <i class=\"fa fa-th\"></i>
              <span>Formations</span>
              </a>
            <ul class=\"sub\">
              <li><a href=\"";
        // line 51
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 1</a></li>
              <li><a href=\"";
        // line 52
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 2</a></li>
              <li><a href=\"";
        // line 53
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 3</a></li>
              <li><a href=\"";
        // line 54
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 4</a></li>
\t\t\t  <li><a href=\"";
        // line 55
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 5</a></li>
            </ul>
          </li>
          <li class=\"sub-menu\">
            <a
              ";
        // line 60
        if (((isset($context["menuActif"]) || array_key_exists("menuActif", $context)) && ((isset($context["menuActif"]) || array_key_exists("menuActif", $context) ? $context["menuActif"] : (function () { throw new RuntimeError('Variable "menuActif" does not exist.', 60, $this->source); })()) == "Membres"))) {
            echo " class=\"active\"  ";
        }
        // line 61
        echo "              href=\"javascript:;\">
              <i class=\"fa fa-user-md\"></i>
              <span>Membres</span>
              </a>
            <ul class=\"sub\">
              <li><a href=\"";
        // line 66
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 1</a></li>
              <li><a href=\"";
        // line 67
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 2</a></li>
              <li><a href=\"";
        // line 68
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 3</a></li>
              <li><a href=\"";
        // line 69
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 4</a></li>
\t\t\t  <li><a href=\"";
        // line 70
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 5</a></li>
            </ul>
          </li>
\t\t  
          <li class=\"sub-menu\">
            <a
              ";
        // line 76
        if (((isset($context["menuActif"]) || array_key_exists("menuActif", $context)) && ((isset($context["menuActif"]) || array_key_exists("menuActif", $context) ? $context["menuActif"] : (function () { throw new RuntimeError('Variable "menuActif" does not exist.', 76, $this->source); })()) == "Intervenants"))) {
            echo " class=\"active\"  ";
        }
        // line 77
        echo "              href=\"javascript:;\">
              <i class=\"fa fa-smile-o\"></i>
              <span>Intervenants</span>
              </a>
            <ul class=\"sub\">
              <li><a href=\"";
        // line 82
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 1</a></li>
              <li><a href=\"";
        // line 83
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 2</a></li>
              <li><a href=\"";
        // line 84
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 3</a></li>
              <li><a href=\"";
        // line 85
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 4</a></li>
\t\t\t  <li><a href=\"";
        // line 86
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("accueil");
        echo "\">sous-menu 5</a></li>
            </ul>
          </li>

        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  218 => 86,  214 => 85,  210 => 84,  206 => 83,  202 => 82,  195 => 77,  191 => 76,  182 => 70,  178 => 69,  174 => 68,  170 => 67,  166 => 66,  159 => 61,  155 => 60,  147 => 55,  143 => 54,  139 => 53,  135 => 52,  131 => 51,  124 => 46,  120 => 45,  111 => 39,  107 => 38,  103 => 37,  99 => 36,  95 => 35,  88 => 30,  84 => 29,  72 => 20,  65 => 15,  61 => 14,  53 => 9,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id=\"sidebar\" class=\"nav-collapse \">
        <!-- sidebar menu start-->
        <ul class=\"sidebar-menu\" id=\"nav-accordion\">
          <p class=\"centered\"><a href=\"profile.html\"><img src=\"{{ asset('assets/img/greece-1162816_640.jpg') }}\" class=\"img-circle\" width=\"80\"></a></p>
          <h5 class=\"centered\">MJC Agora</h5>

          <li class=\"sub-menu\">
            <a
              {% if menuActif is defined and menuActif == 'Jeux' %} class=\"active\"  {% endif %}
              href=\"index.php\" ><i class=\"fa fa-desktop\"></i>
              <span>Jeux vidéos</span>
              </a>
            <ul class=\"sub\">
              <li><a href=\"index.php?uc=gererJeux&action=afficherJeux\">Jeux</a></li>
              <li><a href=\"{{path('genres_afficher')}}\">Genres</a></li>
              <li><a href=\"index.php?uc=gererPlateformes&action=afficherPlateformes\">Plateformes</a></li>
              <li><a href=\"index.php?uc=gererMarques&action=afficherMarques\">Marques</a></li>
              <li><a href=\"index.php?uc=gererPegis&action=afficherPegis\">Pegi</a></li>
\t\t\t  <li><a href=\"index.php?uc=gererTournois&action=afficherTournois\">Tournois</a></li>
            </ul>
          </li>
\t\t  <li class=\"sub-menu\">
            <a
              {% if menuActif is defined and menuActif == 'Clubs' %} class=\"active\"  {% endif %}
              href=\"javascript:;\">
              <i class=\"fa fa-group\"></i>
              <span>Clubs d'activités</span>
              </a>
            <ul class=\"sub\">
              <li><a href=\"{{path('accueil')}}\">sous-menu 1</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 2</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 3</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 4</a></li>
\t\t\t  <li><a href=\"{{path('accueil')}}\">sous-menu 5</a></li>
            </ul>
          </li>
\t\t  
          <li class=\"sub-menu\">
            <a
              {% if menuActif is defined and menuActif == 'Formations' %} class=\"active\"  {% endif %}
              href=\"javascript:;\">
              <i class=\"fa fa-th\"></i>
              <span>Formations</span>
              </a>
            <ul class=\"sub\">
              <li><a href=\"{{path('accueil')}}\">sous-menu 1</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 2</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 3</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 4</a></li>
\t\t\t  <li><a href=\"{{path('accueil')}}\">sous-menu 5</a></li>
            </ul>
          </li>
          <li class=\"sub-menu\">
            <a
              {% if menuActif is defined and menuActif == 'Membres' %} class=\"active\"  {% endif %}
              href=\"javascript:;\">
              <i class=\"fa fa-user-md\"></i>
              <span>Membres</span>
              </a>
            <ul class=\"sub\">
              <li><a href=\"{{path('accueil')}}\">sous-menu 1</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 2</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 3</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 4</a></li>
\t\t\t  <li><a href=\"{{path('accueil')}}\">sous-menu 5</a></li>
            </ul>
          </li>
\t\t  
          <li class=\"sub-menu\">
            <a
              {% if menuActif is defined and menuActif == 'Intervenants' %} class=\"active\"  {% endif %}
              href=\"javascript:;\">
              <i class=\"fa fa-smile-o\"></i>
              <span>Intervenants</span>
              </a>
            <ul class=\"sub\">
              <li><a href=\"{{path('accueil')}}\">sous-menu 1</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 2</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 3</a></li>
              <li><a href=\"{{path('accueil')}}\">sous-menu 4</a></li>
\t\t\t  <li><a href=\"{{path('accueil')}}\">sous-menu 5</a></li>
            </ul>
          </li>

        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
{# {% endblock %}#}", "menu.html.twig", "C:\\wamp64\\www\\AgoraBoS\\templates\\menu.html.twig");
    }
}
